// Made by extension/scripts/build.mjs.
export const CONFIG = {
  "netflixBase": "https://www.netflix.com",
  "netflixHosts": [
    "www.netflix.com",
    "netflix.com"
  ],
  "subtitleHosts": "(^|\\.)nflxvideo\\.net$",
  "subtitleUrls": [
    "https://*.nflxvideo.net/*"
  ],
  "webApp": "https://christiangilkey.github.io/tamkeen/app/",
  "lyricsApi": "https://lrclib.net",
  "version": "0.36.0",
  "test": false
};
