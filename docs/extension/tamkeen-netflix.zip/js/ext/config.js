// Made by extension/scripts/build.mjs.
export const CONFIG = {
  "netflixBase": "https://www.netflix.com",
  "netflixHosts": [
    "www.netflix.com",
    "netflix.com"
  ],
  "subtitleHosts": "(^|\\.)nflxvideo\\.net$",
  "subtitleUrls": [
    "https://*.nflxvideo.net/*"
  ],
  "webApp": "https://learntamkeen.com/",
  "version": "0.53.0",
  "test": false
};
