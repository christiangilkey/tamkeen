// Made by extension/scripts/build.mjs.
export const CONFIG = {
  "netflixBase": "https://www.netflix.com",
  "netflixHosts": [
    "www.netflix.com",
    "netflix.com"
  ],
  "subtitleHosts": "(^|\\.)nflxvideo\\.net$",
  "subtitleUrls": [
    "https://*.nflxvideo.net/*"
  ],
  "webApp": "https://christiangilkey.github.io/tamkeen/app/",
  "version": "0.40.0",
  "test": false
};
