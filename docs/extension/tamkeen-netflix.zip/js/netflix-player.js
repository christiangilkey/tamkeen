// Runs inside Netflix's own watch page, in the window Tamkeen lays over its player's stage (the
// computer's video window, app/netflix_overlay.py), after web/js/netflix-common.js. Netflix's video
// is copy-protected, so it can only play in Netflix's player; this script makes that player part of
// Tamkeen's page:
//   - only the picture shows: Netflix's own controls, subtitles and buttons are hidden, because
//     Tamkeen shows its own clickable subtitles and controls (except when Netflix needs the viewer:
//     "Are you still watching?" or an error, which stay visible). Only the title's own picture, and
//     only while it fills the window: a preview Netflix plays in a small card (the pointer resting
//     on a title it offers, when a title ends) leaves Netflix's page as it is;
//   - when a title starts, the soundtrack is switched to the language being learned when Netflix
//     has one, then the subtitles: Netflix then downloads that subtitle file, which the app's
//     window notices and keeps as the transcript. This happens once per title (and again when the
//     language being learned changes); a soundtrack or subtitles the viewer picks in Tamkeen's own
//     menus (the browser extension's bar) are kept for the rest of the title;
//   - the app asks it where the player is (state, with Netflix's lists of soundtracks and
//     subtitles) and tells it what to do (cmd).
// Netflix's player is reached through the API its own page uses:
//   netflix.appContext.state.playerApp.getAPI().videoPlayer -> getVideoPlayerBySessionId(...)
// whose times are in milliseconds. (Setting the <video>'s currentTime directly makes Netflix stop
// with an error: always seek through it.)
//
// Like the other scripts that run inside someone else's website it is plain script, uses no
// innerHTML and leaves the page's own code alone.
(function () {
  if (window.top !== window || window.__tamkeenNetflixPlayer) return;
  var cfg = window.__tamkeenNetflixCfg || {};
  var hosts = cfg.hosts || ["www.netflix.com", "netflix.com"];
  var lib = window.__tamkeenNetflixLib;
  if (hosts.indexOf(location.hostname) < 0 || !lib) return;
  // The language being learned. Read each time: the browser extension (extension/) tells the page
  // only once it has read its settings, a moment after this script starts.
  var LANG = "";
  function readLang() { LANG = String((window.__tamkeenNetflixCfg || cfg).lang || ""); return LANG; }
  readLang();

  var style = document.createElement("style");
  // Netflix's subtitles never show (Tamkeen shows its own); while a title plays, nothing but the
  // picture does. (visibility, not display: Netflix's own code keeps working, and the video,
  // made visible again inside its hidden boxes, still fills the window.)
  style.textContent = ".player-timedtext, .player-timedtext-text-container { display: none !important; }" +
    "html.tk-only-video, html.tk-only-video body { background: #000 !important; cursor: default !important; }" +
    "html.tk-only-video body * { visibility: hidden !important; }" +
    "html.tk-only-video video { visibility: visible !important; }";
  (document.head || document.documentElement).appendChild(style);

  // ---------- Netflix's page ----------
  /** The player of the title playing, or null while there is none. Not a preview's: a card that plays
   * when the pointer rests on a title has a player session of its own (lib.titleSession). */
  function player() {
    try {
      var vp = window.netflix.appContext.state.playerApp.getAPI().videoPlayer;
      var sid = lib.titleSession(vp.getAllPlayerSessionIds(), lib.watchId(location.href), function (id) {
        var s = vp.getVideoPlayerBySessionId(id);
        return s && typeof s.getMovieId === "function" ? s.getMovieId() : "";
      });
      var p = sid ? vp.getVideoPlayerBySessionId(sid) : null;
      return p ? { p: p, sid: sid } : null;
    } catch (e) { return null; }
  }
  function pageKind() {
    var path = location.pathname;
    if (/^\/watch\//.test(path)) return "watch";
    // The sign-in page, or Netflix's front page for visitors ("/", "/us/", "/gb-en/"): not signed in.
    if (/^\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?(?:login|signup)/i.test(path) || /^\/(?:[a-z]{2}(?:-[a-z]{2})?\/?)?$/i.test(path) ||
        document.querySelector("form[data-uia='login-page-container'], input[name='userLoginId']")) return "login";
    if (/^\/profiles/.test(path) || document.querySelector(".profile-gate-container, [data-uia='profile-gate']")) return "profiles";
    return "other";
  }
  function visibleText(el) {
    if (!el) return "";
    var r = el.getBoundingClientRect ? el.getBoundingClientRect() : null;
    if (r && (r.width < 2 || r.height < 2)) return "";
    return String(el.innerText || el.textContent || "").replace(/\s+/g, " ").trim().slice(0, 300);
  }
  /** Netflix saying something went wrong ("Pardon the interruption", too many screens…). */
  function errorText() {
    return visibleText(document.querySelector(".nf-error, .error-page, [data-uia='player-error'], [data-uia='error-page'], " +
      ".watch-video--error-container, .nfp-fatal-error-view"));
  }
  /** Netflix asking the viewer something ("Are you still watching?"). */
  function prompt() {
    return document.querySelector("[data-uia*='interrupt'], .interrupter-modal");
  }
  /** The space the title's picture has: the window, less what Tamkeen's bar and sidebar take in the
   * browser extension (which sizes the picture itself, content/netflix.js, and says how much they take). */
  function space() {
    var root = document.documentElement;
    var sized = root.classList && root.classList.contains && root.classList.contains("tk-ext");
    var taken = function (name) { return sized && root.style ? parseFloat(root.style.getPropertyValue(name)) || 0 : 0; };
    return { w: Number(window.innerWidth) - taken("--tk-side"), h: Number(window.innerHeight) - taken("--tk-bar") };
  }
  function boxOf(v) {
    try { return typeof v.getBoundingClientRect === "function" ? v.getBoundingClientRect() : null; } catch (e) { return null; }
  }
  /** The title's picture: the biggest <video> on the page, or null. `fills`: it fills the window,
   * as the title playing does (lib.fills); a preview card or the shrunken end credits don't. */
  function video() {
    var list = document.querySelectorAll("video");
    var best = null;
    var area = -1;
    for (var i = 0; i < list.length; i++) {
      var b = boxOf(list[i]);
      var a = b ? Number(b.width) * Number(b.height) : 0;
      if (a >= area) { best = list[i]; area = a; } // (equal sizes: the newest, as Netflix adds them last)
    }
    return best;
  }
  function fillsWindow(v) { return !!v && lib.fills(boxOf(v), space()); }
  function call(p, name) {
    try { return typeof p[name] === "function" ? p[name]() : undefined; } catch (e) { return undefined; }
  }

  // ---------- once per title (and when the language being learned changes): soundtrack, then subtitles ----------
  // Chosen ONCE, never forced back: the viewer may change either in Tamkeen's Audio and Subtitles
  // menus (cmd "audio" / "text"), and a track chosen by hand is kept for the rest of the title
  // (lib.planChoice, lib.choseByHand).
  var plan = {};      // {session, lang, manualAudio, manualText}
  var subs = { status: "waiting", bcp47: "", name: "" };
  var sound = { status: "waiting", name: "" };
  var textAt = 0;     // when to choose the subtitles (a moment after switching the soundtrack)
  var textTries = 0;

  function choose(found) {
    var p = found.p;
    var now = Date.now();
    var newTitle = plan.session !== found.sid; // a new title (or the next episode)
    var again = lib.planChoice(plan, found.sid, readLang());
    if (newTitle) {
      subs = { status: "waiting", bcp47: "", name: "" };
      sound = { status: "waiting", name: "" };
      textAt = 0;
      textTries = 0;
    }
    if (again.audio) sound = { status: "waiting", name: "" };
    if (again.text) { subs = { status: "waiting", bcp47: "", name: "" }; textAt = 0; textTries = 0; }
    if (!LANG) return;
    if (sound.status === "waiting") {
      var list = call(p, "getAudioTrackList");
      if (!list) return;
      var current = call(p, "getAudioTrack");
      var pick = lib.chooseAudioTrack(list, LANG, current);
      if (pick) {
        try { p.setAudioTrack(pick); } catch (e) { /* this one can't be switched to */ }
        sound = { status: "switched", name: String(pick.displayName || pick.bcp47 || "") };
        textAt = now + 1500; // the list of subtitles follows the soundtrack
      } else {
        sound = { status: current && lib.base(current.bcp47) === lib.base(LANG) ? "already" : "none",
                  name: String((current && current.displayName) || "") };
        textAt = now;
      }
      return;
    }
    if (subs.status !== "waiting" || now < textAt) return;
    var tracks = call(p, "getTextTrackList") || [];
    if (!tracks.length && ++textTries < 15) { textAt = now + 700; return; }
    var heard = call(p, "getAudioTrack");
    var choice = lib.chooseTextTrack(tracks, LANG, heard && heard.bcp47);
    if (!choice) { subs = { status: "none", bcp47: "", name: "" }; return; }
    var named = { bcp47: String(choice.track.bcp47 || ""), name: String(choice.track.displayName || "") };
    if (choice.image) { subs = { status: "image", bcp47: named.bcp47, name: named.name }; return; }
    subs = { status: "chosen", bcp47: named.bcp47, name: named.name };
    try {
      var done = p.setTextTrack(choice.track);
      if (done && done.catch) done.catch(function () { subs.status = "failed"; });
    } catch (e) { subs.status = "failed"; }
  }

  /** Netflix's own description of the title playing, when its page has it. */
  function readInfo(id) {
    try {
      var vm = window.netflix.appContext.state.playerApp.getState().videoPlayer.videoMetadata;
      var entry = vm && (vm[id] || vm[Number(id)]);
      var meta = entry && (entry._metadata ? entry._metadata.video : entry.video || null);
      return meta ? lib.titleInfo(meta, id) : null;
    } catch (e) { return null; }
  }

  function tick() {
    // Only on a title's own page (/watch/...): Netflix's home and browse pages play trailers with a
    // player of their own, and treating one as the title playing hid the whole page but the trailer
    // (dark once scrolled past it) and changed the trailer's soundtrack.
    // And only while the title's picture fills the window: on a watch page Netflix also shows titles
    // to pick (when a title ends, say), and the pointer resting on one plays a preview in a small
    // card. Taken for the title, it hid everything but that card, and Netflix couldn't be used.
    var found = pageKind() === "watch" ? player() : null;
    document.documentElement.classList.toggle("tk-only-video", !!(found && fillsWindow(video()) && !prompt() && !errorText()));
    if (found) choose(found);
  }
  setInterval(tick, 400);
  tick();

  function state() {
    var found = player();
    var p = found && found.p;
    var v = video();
    var id = lib.watchId(location.href);
    var t = p ? Number(call(p, "getCurrentTime")) / 1000 : 0;
    var d = p && typeof p.getDuration === "function" ? Number(call(p, "getDuration")) / 1000 : 0;
    if (!(d > 0) && v && isFinite(v.duration)) d = v.duration;
    var paused = p ? !!call(p, "isPaused") : true;
    var asking = prompt();
    return {
      v: 1, page: pageKind(), id: id, sid: found ? found.sid : "", ready: !!p, video: !!v,
      t: isFinite(t) ? Math.max(0, t) : 0, d: isFinite(d) && d > 0 ? d : 0, paused: paused,
      ended: !!(v && v.ended) || (!!p && paused && d > 0 && t >= d - 0.6),
      rate: p ? Number(call(p, "getPlaybackRate")) || 1 : 1,
      error: errorText(), prompt: asking ? visibleText(asking) || "?" : "",
      subs: subs, audio: sound, info: id ? readInfo(id) : null,
      learning: LANG, tracks: p ? tracks(p) : null,
      manual: { audio: !!plan.manualAudio, text: !!plan.manualText },
    };
  }

  /** Netflix's soundtracks and subtitles for Tamkeen's menus, and the ones in use. */
  function tracks(p) {
    var audio = call(p, "getAudioTrackList") || [];
    var text = call(p, "getTextTrackList") || [];
    return {
      audio: lib.menuTracks(audio, "audio"), text: lib.menuTracks(text, "text"),
      audioNow: lib.currentKey(audio, call(p, "getAudioTrack"), "audio"),
      textNow: lib.currentKey(text, call(p, "getTextTrack"), "text"),
    };
  }

  /** The viewer chose a soundtrack (`kind` "audio") or subtitles ("text"; key "off" turns them off)
   * in Tamkeen's menus: Netflix switches to it, and it is kept for the rest of this title. */
  function chooseByHand(p, kind, key) {
    if (kind === "audio") {
      var a = lib.findTrack(call(p, "getAudioTrackList"), key);
      if (!a) return;
      p.setAudioTrack(a);
      sound = { status: "manual", name: String(a.displayName || a.bcp47 || "") };
      if (lib.choseByHand(plan, "audio") && LANG) { // the subtitles in the language being learned, once more
        subs = { status: "waiting", bcp47: "", name: "" };
        textAt = Date.now() + 1500;
        textTries = 0;
      }
      return;
    }
    var list = call(p, "getTextTrackList") || [];
    var off = String(key) === "off";
    var tr = off ? lib.offTrack(list) : lib.findTrack(list, key);
    if (!tr && !off) return;
    lib.choseByHand(plan, "text");
    subs = off ? { status: "off", bcp47: "", name: "" } : { status: "manual", bcp47: String(tr.bcp47 || ""), name: String(tr.displayName || "") };
    if (tr) {
      var done = p.setTextTrack(tr);
      if (done && done.catch) done.catch(function () { /* the next state shows the track Netflix kept */ });
    }
  }

  function cmd(name, value) {
    var found = player();
    var p = found && found.p;
    if (!p) return state();
    try {
      if (name === "play") p.play();
      else if (name === "pause") p.pause();
      else if (name === "seek") p.seek(Math.max(0, Math.round(Number(value) * 1000)));
      else if (name === "rate") {
        var r = Math.max(0.5, Math.min(2, Number(value) || 1));
        try { p.setPlaybackRate(r); } catch (e) { var v = video(); if (v) v.playbackRate = r; }
      } else if (name === "audio" || name === "text") {
        chooseByHand(p, name, String(value || ""));
      } else if (name === "continue") {
        var asking = prompt();
        var b = asking && asking.querySelector("button");
        if (b) b.click();
      }
    } catch (e) { /* Netflix refused this one: the next state says where it is */ }
    return state();
  }

  window.__tamkeenNetflixPlayer = { state: state, cmd: cmd };
})();
