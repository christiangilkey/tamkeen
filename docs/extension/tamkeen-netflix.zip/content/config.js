// Made by extension/scripts/build.mjs: which website js/netflix-player.js treats as Netflix.
window.__tamkeenNetflixCfg = {"hosts":["www.netflix.com","netflix.com"],"lang":""};
